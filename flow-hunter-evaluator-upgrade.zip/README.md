# FLOW HUNTER Evaluator Upgrade

Adds richer replay analytics:
- MFE / MAE tracking
- trade duration in ticks
- win rate by regime
- confidence bucket stats

Run:
export PYTHONPATH=src
python3 scripts/run_csv_replay.py
