from flow_hunter.ingest.csv_replay import CSVReplayReader
from flow_hunter.runner import FlowHunterRunner
from flow_hunter.replay.evaluator import ReplayEvaluator
from flow_hunter.replay.metrics import Metrics

def main() -> None:
    rows = CSVReplayReader("data/sample_ticks.csv").read()
    runner = FlowHunterRunner()
    evaluator = ReplayEvaluator(target_pips=2.0, stop_pips=1.0)
    metrics = Metrics()

    for raw in rows:
        result = runner.on_raw_tick(raw)
        advisory = result["advisory"]
        print(advisory)
        price = raw["bid"]
        if advisory["verdict"] == "hunt_long":
            evaluator.on_signal(price, "long", advisory["regime"], advisory["confidence"])
        elif advisory["verdict"] == "hunt_short":
            evaluator.on_signal(price, "short", advisory["regime"], advisory["confidence"])
        evaluator.on_tick(price)

    evaluator.close_open_trade()
    report = metrics.compute(evaluator.results)
    print("\n=== PERFORMANCE ===")
    print(report)

if __name__ == "__main__":
    main()
