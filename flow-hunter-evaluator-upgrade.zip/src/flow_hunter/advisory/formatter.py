from flow_hunter.schemas.advisory import Advisory
from flow_hunter.schemas.control_state import ControlState
from flow_hunter.schemas.regime_state import RegimeState

class AdvisoryFormatter:
    def format(self, regime: RegimeState, control: ControlState, confidence: float) -> Advisory:
        if regime.label == "unstable":
            return Advisory(regime.pair, regime.label, control.side, "wait", 0.20, ["unstable spread/tape"])
        if control.side == "neutral":
            return Advisory(regime.pair, regime.label, control.side, "wait", 0.25, ["no clear tape control"])
        verdict = "hunt_long" if control.side == "long" else "hunt_short"
        reasons = []
        reasons.extend(regime.notes[:1])
        reasons.extend(control.notes[:1])
        return Advisory(regime.pair, regime.label, control.side, verdict, confidence, reasons)
