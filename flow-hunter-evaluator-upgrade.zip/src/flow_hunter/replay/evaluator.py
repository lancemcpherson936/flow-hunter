from dataclasses import dataclass

@dataclass
class TradeResult:
    entry_price: float
    direction: str
    regime: str
    confidence: float
    ticks_open: int = 0
    max_favorable: float = 0.0
    max_adverse: float = 0.0
    outcome: str = "open"

class ReplayEvaluator:
    def __init__(self, target_pips: float = 2.0, stop_pips: float = 1.0):
        self.target = target_pips
        self.stop = stop_pips
        self.active_trade = None
        self.results = []

    def on_signal(self, price: float, direction: str, regime: str, confidence: float) -> None:
        if self.active_trade is None:
            self.active_trade = TradeResult(price, direction, regime, confidence)

    def on_tick(self, price: float) -> None:
        if not self.active_trade:
            return
        trade = self.active_trade
        trade.ticks_open += 1
        move = (price - trade.entry_price) * 10000
        if trade.direction == "short":
            move *= -1
        trade.max_favorable = max(trade.max_favorable, move)
        trade.max_adverse = min(trade.max_adverse, move)
        if move >= self.target:
            trade.outcome = "win"
            self.results.append(trade)
            self.active_trade = None
        elif move <= -self.stop:
            trade.outcome = "loss"
            self.results.append(trade)
            self.active_trade = None

    def close_open_trade(self) -> None:
        if self.active_trade is not None:
            self.active_trade.outcome = "timeout"
            self.results.append(self.active_trade)
            self.active_trade = None
