class Metrics:
    @staticmethod
    def _bucket(confidence: float) -> str:
        if confidence < 0.60:
            return "<0.60"
        if confidence < 0.75:
            return "0.60-0.74"
        if confidence < 0.90:
            return "0.75-0.89"
        return ">=0.90"

    def compute(self, results):
        if not results:
            return {"total_trades": 0, "wins": 0, "losses": 0, "timeouts": 0, "win_rate": 0.0, "avg_win_pips": 0.0, "avg_loss_pips": 0.0, "avg_mfe_pips": 0.0, "avg_mae_pips": 0.0, "avg_ticks_open": 0.0, "by_regime": {}, "by_confidence_bucket": {}}

        wins = sum(1 for r in results if r.outcome == "win")
        losses = sum(1 for r in results if r.outcome == "loss")
        timeouts = sum(1 for r in results if r.outcome == "timeout")
        total = len(results)
        resolved = max(wins + losses, 1)
        win_rate = wins / resolved if resolved else 0.0

        avg_win = sum(r.max_favorable for r in results if r.outcome == "win") / max(wins, 1)
        avg_loss = sum(abs(r.max_adverse) for r in results if r.outcome == "loss") / max(losses, 1)
        avg_mfe = sum(r.max_favorable for r in results) / total
        avg_mae = sum(abs(r.max_adverse) for r in results) / total
        avg_ticks = sum(r.ticks_open for r in results) / total

        by_regime = {}
        for r in results:
            row = by_regime.setdefault(r.regime, {"trades": 0, "wins": 0, "losses": 0, "timeouts": 0})
            row["trades"] += 1
            if r.outcome == "win":
                row["wins"] += 1
            elif r.outcome == "loss":
                row["losses"] += 1
            else:
                row["timeouts"] += 1
        for regime, row in by_regime.items():
            denom = max(row["wins"] + row["losses"], 1)
            row["win_rate"] = round(row["wins"] / denom, 2)

        by_bucket = {}
        for r in results:
            bucket = self._bucket(r.confidence)
            row = by_bucket.setdefault(bucket, {"trades": 0, "wins": 0, "losses": 0, "timeouts": 0})
            row["trades"] += 1
            if r.outcome == "win":
                row["wins"] += 1
            elif r.outcome == "loss":
                row["losses"] += 1
            else:
                row["timeouts"] += 1
        for bucket, row in by_bucket.items():
            denom = max(row["wins"] + row["losses"], 1)
            row["win_rate"] = round(row["wins"] / denom, 2)

        return {
            "total_trades": total,
            "wins": wins,
            "losses": losses,
            "timeouts": timeouts,
            "win_rate": round(win_rate, 2),
            "avg_win_pips": round(avg_win, 2),
            "avg_loss_pips": round(avg_loss, 2),
            "avg_mfe_pips": round(avg_mfe, 2),
            "avg_mae_pips": round(avg_mae, 2),
            "avg_ticks_open": round(avg_ticks, 2),
            "by_regime": by_regime,
            "by_confidence_bucket": by_bucket,
        }
